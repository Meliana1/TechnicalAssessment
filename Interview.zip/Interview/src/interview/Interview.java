/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interview;

import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class Interview {

        /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        String x = "aaaaanaapaaa";
            int[] num = new int[10];
            int count =0;
        for(int i = 0; i<x.length()-2;i++){
            if(x.charAt(i)== x.charAt(i+1) && x.charAt(i)== x.charAt(i+2)){
               num[count]= i;
              count++;
            }
        }
        for(int j = 0; j<= count;j++){
        System.out.print(num[j]+", ");
        }
    }
    
}
