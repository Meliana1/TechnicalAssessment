
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lenovo
 */

abstract class Animal {
     public void fly(){
     
    }
    public void walk(){
    
    }
    public void swim(){
    
    }
}

class Bird extends Animal {
    public void fly() {
        System.out.println("Flying");
    }
    public void walk() {
        System.out.println("Walking");
    }
    public void swim() {
        try {
            throw new Exception("Not supported");
        } catch (Exception ex) {
            Logger.getLogger(Bird.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

class Fish extends Animal {
    public void swim() {
        System.out.println("Swimming");
    }
    
    public void walk() {
        try {
            throw new Exception("Not supported");
        } catch (Exception ex) {
            Logger.getLogger(Fish.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void fly() {
        try {
            throw new Exception("Not supported");
        } catch (Exception ex) {
            Logger.getLogger(Fish.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}

public class Q4 {
    public static void main(String[] args) {
        Fish fish = new Fish();
    fish.swim(); // works
    fish.walk(); // exception
    fish.fly(); // exception
    
    Bird bird = new Bird();
    bird.fly(); // works
    bird.swim(); //exception
    }
    
     

}

