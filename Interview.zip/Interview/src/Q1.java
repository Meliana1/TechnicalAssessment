
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lenovo
 */
public class Q1 {
    
    public static void findJumpingWays(int N){
        int [] num = new int[100];
        num[0]= 1;
        num[1] = 1;
        num [2] = 2;
            for(int i=3; i<=N;i++){
                num[i] = num[i-1] + num [i-2];
            }
            System.out.println(num[N]);
    }
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("number of rock: ");
        int number = input.nextInt();
        
        findJumpingWays(number);
    }
    
}
