/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lenovo
 */
public class Q3 {
     public static void main(String[] args) {
        String[] words = {"zero", "real", "name", "zero", "help", "hero", "real", "none", "real"};
        findWordWithfrequency (3,words);
    }
    
    public static void findWordWithfrequency (int N, String[] wordList){
        for (int i=0; i<N; i++) {
            System.out.print (wordList [i]+ " , ");
        }
    }  
    
}
